export { default } from "./Paginator";
