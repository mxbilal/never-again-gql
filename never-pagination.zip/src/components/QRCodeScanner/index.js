import Html5QrcodePlugin from "./QRCodeScanner";
import ResultContainerPlugin from "./ResultContainerPlugin";

export { Html5QrcodePlugin, ResultContainerPlugin };
