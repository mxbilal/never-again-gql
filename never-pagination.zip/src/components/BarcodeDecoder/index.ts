export { default } from "./BarcodeDecoder";
