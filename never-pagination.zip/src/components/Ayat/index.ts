export { default } from "./Ayat";
