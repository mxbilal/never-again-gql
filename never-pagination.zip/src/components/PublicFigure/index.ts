export { default } from "./PublicFigure";
