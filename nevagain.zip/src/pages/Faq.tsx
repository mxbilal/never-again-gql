import React from "react";

const Faq = () => {
  return (
    <>
      <section className="w-full flex flex-col justify-center items-center my-12 md:mx-0">
        <div className="w-full">
          <h2>FAQs</h2>
          <h3>Question</h3>
          <p>
            <b>Answer</b> Lorem ipsum, dolor sit amet consectetur adipisicing
            elit. Reprehenderit, illo explicabo. Delectus aperiam illum odio
            quisquam aut ullam, quae iusto ex quis perferendis ad, incidunt
            dolore ipsum tempore, voluptates esse?
          </p>
          <p>
            <b>Answer</b> Lorem ipsum, dolor sit amet consectetur adipisicing
            elit. Reprehenderit, illo explicabo. Delectus aperiam illum odio
            quisquam aut ullam, quae iusto ex quis perferendis ad, incidunt
            dolore ipsum tempore, voluptates esse?
          </p>
          <p>
            <b>Answer</b> Lorem ipsum, dolor sit amet consectetur adipisicing
            elit. Reprehenderit, illo explicabo. Delectus aperiam illum odio
            quisquam aut ullam, quae iusto ex quis perferendis ad, incidunt
            dolore ipsum tempore, voluptates esse?
          </p>
          <p>
            <b>Answer</b> Lorem ipsum, dolor sit amet consectetur adipisicing
            elit. Reprehenderit, illo explicabo. Delectus aperiam illum odio
            quisquam aut ullam, quae iusto ex quis perferendis ad, incidunt
            dolore ipsum tempore, voluptates esse?
          </p>
        </div>
      </section>
    </>
  );
};

export default Faq;
