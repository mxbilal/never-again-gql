import React from "react";

const Boycott = () => {
  return (
    <>
      <section className="w-full flex flex-col justify-center items-center my-12 md:mx-0">
        <div className="w-full">
          <h1>How, Why and Proof it Works</h1>
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit.
            Reprehenderit, illo explicabo. Delectus aperiam illum odio quisquam
            aut ullam, quae iusto ex quis perferendis ad, incidunt dolore ipsum
            tempore, voluptates esse?
          </p>
          <br />
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit.
            Reprehenderit, illo explicabo. Delectus aperiam illum odio quisquam
            aut ullam, quae iusto ex quis perferendis ad, incidunt dolore ipsum
            tempore, voluptates esse?
          </p>
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit.
            Reprehenderit, illo explicabo. Delectus aperiam illum odio quisquam
            aut ullam, quae iusto ex quis perferendis ad, incidunt dolore ipsum
            tempore, voluptates esse?
          </p>
          <br />
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit.
            Reprehenderit, illo explicabo. Delectus aperiam illum odio quisquam
            aut ullam, quae iusto ex quis perferendis ad, incidunt dolore ipsum
            tempore, voluptates esse?
          </p>
          <br />
          <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit.
            Reprehenderit, illo explicabo. Delectus aperiam illum odio quisquam
            aut ullam, quae iusto ex quis perferendis ad, incidunt dolore ipsum
            tempore, voluptates esse?
          </p>
        </div>
      </section>
    </>
  );
};

export default Boycott;
