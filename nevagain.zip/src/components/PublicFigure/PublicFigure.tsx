import React from "react";

// this component is supposed to be the generic skeleton for the content on both the leaf pages of politician and celebrity
// start with cut pasting code from the celebrity page and then call this component there

const PublicFigure = () => {
  return <div>PublicFigure</div>;
};

export default PublicFigure;
