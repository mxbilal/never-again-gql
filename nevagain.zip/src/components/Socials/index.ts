export { default } from "./Socials";
