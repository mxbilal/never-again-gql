export { default } from "./Search";
