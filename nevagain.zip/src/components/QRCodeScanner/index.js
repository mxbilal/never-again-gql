export { default } from "./QRCodeScanner";
